A Pen created at CodePen.io. You can find this one at http://codepen.io/ivanrafael/pen/exsaq.

 This Pie chart based on my doughnut SVG chart:  http://codepen.io/githiro/details/ICfFE

Forked from [hiro](/githiro)'s Pen [SVG Pie chart with tooltip and mouse effects](/githiro/pen/xABCi/).